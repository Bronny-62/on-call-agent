import { describe, expect, it, beforeAll, afterAll } from "vitest";
import type { FastifyInstance } from "fastify";
import Fastify from "fastify";
import { buildApp } from "../src/server/app.js";
import { parseHtmlDocument } from "../src/server/documents/parser.js";
import { isSafeFilename } from "../src/server/agent/tools.js";
import { readFile } from "node:fs/promises";
import path from "node:path";

describe("On-Call Agent app", () => {
  let app: FastifyInstance;
  let mockLlm: FastifyInstance;
  let originalEnv: NodeJS.ProcessEnv;

  beforeAll(async () => {
    originalEnv = { ...process.env };
    mockLlm = Fastify();
    mockLlm.post("/v1/chat/completions", async (request, reply) => {
      const body = request.body as { messages: Array<{ role: string }>; stream?: boolean };
      const hasToolResult = body.messages.some((message) => message.role === "tool");
      if (body.stream) {
        reply.raw.writeHead(200, {
          "Content-Type": "text/event-stream"
        });
        reply.raw.write('data: {"choices":[{"delta":{"role":"assistant","content":""},"finish_reason":null}]}\n\n');
        reply.raw.write('data: {"choices":[{"delta":{"content":"数据库DBA On-Call SOP：先确认主从延迟、复制线程状态和错误信息"},"finish_reason":null}]}\n\n');
        reply.raw.write('data: {"choices":[{"delta":{"content":"，再按 SOP 执行恢复。"},"finish_reason":null}]}\n\n');
        reply.raw.write("data: [DONE]\n\n");
        reply.raw.end();
        return reply;
      }

      if (!hasToolResult) {
        return {
          choices: [
            {
              message: {
                role: "assistant",
                content: null,
                tool_calls: [
                  {
                    id: "call-read-sop-002",
                    type: "function",
                    function: {
                      name: "readFile",
                      arguments: JSON.stringify({ fname: "sop-002.html" })
                    }
                  }
                ]
              }
            }
          ]
        };
      }

      return {
        choices: [
          {
            message: {
              role: "assistant",
              content: "数据库DBA On-Call SOP：先确认主从延迟、复制线程状态和错误信息，再按 SOP 执行恢复。"
            }
          }
        ]
      };
    });
    await mockLlm.listen({ port: 0, host: "127.0.0.1" });
    const address = mockLlm.server.address();
    if (!address || typeof address === "string") throw new Error("mock LLM server did not start");
    process.env.LLM_API_KEY = "test-key";
    process.env.LLM_BASE_URL = `http://127.0.0.1:${address.port}/v1`;
    process.env.LLM_MODEL = "kimi-k2.6";

    app = await buildApp({ rootDir: process.cwd() });
  });

  afterAll(async () => {
    await app.close();
    await mockLlm.close();
    process.env = originalEnv;
  });

  it("extracts visible text and ignores scripts/styles", async () => {
    const html = await readFile(path.join(process.cwd(), "data", "sop-002.html"), "utf-8");
    const document = parseHtmlDocument("sop-002", html);

    expect(document.title).toBe("数据库DBA On-Call SOP");
    expect(document.text).toContain("主从复制状态");
    expect(document.text).not.toContain("replicationLag");
  });

  it("passes Phase 1 keyword search cases", async () => {
    const oom = await app.inject({ method: "GET", url: "/v1/search?q=OOM" });
    expect(oom.json().results[0].id).toBe("sop-001");

    const incident = await app.inject({ method: "GET", url: "/v1/search?q=%E6%95%85%E9%9A%9C" });
    expect(incident.json().results.length).toBeGreaterThan(3);

    const replication = await app.inject({ method: "GET", url: "/v1/search?q=replication" });
    expect(replication.json().results).toHaveLength(0);

    const cdn = await app.inject({ method: "GET", url: "/v1/search?q=CDN" });
    const cdnIds = cdn.json().results.map((result: { id: string }) => result.id);
    expect(cdnIds).toContain("sop-003");
    expect(cdnIds).toContain("sop-010");

    const ampersand = await app.inject({ method: "GET", url: "/v1/search?q=%26" });
    expect(ampersand.json().results.length).toBeGreaterThan(0);
  });

  it("serves a styled document view without running source scripts", async () => {
    const response = await app.inject({ method: "GET", url: "/documents/sop-001.html" });

    expect(response.statusCode).toBe(200);
    expect(response.headers["content-type"]).toContain("text/html");
    expect(response.body).toContain("documentCard");
    expect(response.body).toContain("后端服务 On-Call SOP");
    expect(response.body).not.toContain("<script>var");
  });

  it("passes Phase 2 semantic search cases", async () => {
    const serverDown = await app.inject({ method: "GET", url: "/v2/search?q=%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%8C%82%E4%BA%86" });
    const serverIds = serverDown.json().results.slice(0, 2).map((result: { id: string }) => result.id);
    expect(serverIds).toContain("sop-001");
    expect(serverIds).toContain("sop-004");

    const attack = await app.inject({ method: "GET", url: "/v2/search?q=%E9%BB%91%E5%AE%A2%E6%94%BB%E5%87%BB" });
    expect(attack.json().results[0].id).toBe("sop-005");

    const ml = await app.inject({
      method: "GET",
      url: "/v2/search?q=%E6%9C%BA%E5%99%A8%E5%AD%A6%E4%B9%A0%E6%A8%A1%E5%9E%8B%E5%87%BA%E9%97%AE%E9%A2%98"
    });
    expect(ml.json().results[0].id).toBe("sop-008");
  });

  it("shows readFile tool traces for Phase 3", async () => {
    const response = await app.inject({
      method: "POST",
      url: "/v3/chat",
      payload: { message: "数据库主从延迟超过30秒怎么处理？" }
    });
    const json = response.json();

    expect(json.toolCalls[0].name).toBe("readFile");
    expect(json.toolCalls[0].args.fname).toBe("sop-002.html");
    expect(json.answer).toContain("数据库DBA On-Call SOP");
  });

  it("streams Phase 3 status, tool calls, and answer chunks", async () => {
    const response = await app.inject({
      method: "POST",
      url: "/v3/chat/stream",
      payload: { message: "数据库主从延迟超过30秒怎么处理？" }
    });

    expect(response.statusCode).toBe(200);
    expect(response.headers["content-type"]).toContain("text/event-stream");
    expect(response.body).toContain("\"type\":\"status\"");
    expect(response.body).toContain("\"type\":\"tool_call\"");
    expect(response.body).toContain("\"type\":\"tool_result\"");
    expect(response.body).toContain("\"type\":\"answer_delta\"");
    expect(response.body).toContain("\"type\":\"done\"");
  });

  it("restricts readFile filenames", () => {
    expect(isSafeFilename("sop-002.html")).toBe(true);
    expect(isSafeFilename("../sop-002.html")).toBe(false);
    expect(isSafeFilename("*.html")).toBe(false);
    expect(isSafeFilename("README.md")).toBe(false);
  });
});
