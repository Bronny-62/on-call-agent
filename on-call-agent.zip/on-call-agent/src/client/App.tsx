import { ParticleBackdrop } from "./components/ParticleBackdrop";
import { ChatPage } from "./pages/ChatPage";
import { SearchPage } from "./pages/SearchPage";

export function App() {
  const pathname = window.location.pathname;
  const page = pathname.startsWith("/v3") ? "v3" : pathname.startsWith("/v2") ? "v2" : "v1";

  return (
    <>
      <ParticleBackdrop />
      <main className="shell">
        <nav className="topbar">
          <a className="brand" href="/v1">
            <span className="brandMark">A</span>
            On-Call Agent
          </a>
          <div className="navLinks">
            <a className={page === "v1" ? "active" : ""} href="/v1">
              Phase 1
            </a>
            <a className={page === "v2" ? "active" : ""} href="/v2">
              Phase 2
            </a>
            <a className={page === "v3" ? "active" : ""} href="/v3">
              Phase 3
            </a>
          </div>
        </nav>

        {page === "v3" ? <ChatPage /> : <SearchPage phase={page} />}
      </main>
    </>
  );
}
