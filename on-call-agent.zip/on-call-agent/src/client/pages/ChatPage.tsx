import { FormEvent, useState } from "react";
import type { ReactNode } from "react";

interface ToolCall {
  name: "readFile";
  args: {
    fname: string;
  };
  resultPreview: string;
}

interface AgentBlock {
  id: string;
  kind: "status" | "tool" | "answer" | "error";
  title?: string;
  content: string;
  pending?: boolean;
}

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  blocks?: AgentBlock[];
  pending?: boolean;
}

interface StreamEvent {
  type: "status" | "tool_call" | "tool_result" | "answer_delta" | "done" | "error";
  message?: string;
  text?: string;
  call?: ToolCall;
}

export function ChatPage() {
  const [message, setMessage] = useState("数据库主从延迟超过30秒怎么处理？");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const question = message.trim();
    if (!question || loading) return;

    const userMessage: ChatMessage = {
      id: makeId(),
      role: "user",
      content: question
    };
    const assistantId = makeId();
    const assistantMessage: ChatMessage = {
      id: assistantId,
      role: "assistant",
      content: "",
      pending: true,
      blocks: [
        {
          id: makeId(),
          kind: "status",
          content: "思考中...",
          pending: true
        }
      ]
    };

    setMessages((current) => [...current, userMessage, assistantMessage]);
    setMessage("");
    setLoading(true);

    try {
      const result = await fetch("/v3/chat/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: question })
      });

      if (!result.ok || !result.body) {
        throw new Error(`HTTP ${result.status}`);
      }

      await readStream(result.body, (eventData) => {
        applyStreamEvent(assistantId, eventData);
      });
    } finally {
      setLoading(false);
      setMessages((current) =>
        current.map((item) =>
          item.id === assistantId
            ? {
                ...item,
                pending: false,
                blocks: item.blocks?.map((block) => ({ ...block, pending: false }))
              }
            : item
        )
      );
    }
  };

  const applyStreamEvent = (assistantId: string, eventData: StreamEvent) => {
    setMessages((current) =>
      current.map((item) => {
        if (item.id !== assistantId) return item;
        const blocks = item.blocks ?? [];

        if (eventData.type === "status") {
          return {
            ...item,
            blocks: upsertStatusBlock(blocks, eventData.message || "思考中...")
          };
        }

        if (eventData.type === "tool_call" && eventData.call) {
          return {
            ...item,
            blocks: [
              ...finishStatus(blocks),
              {
                id: makeId(),
                kind: "tool",
                title: `readFile(${eventData.call.args.fname || "..."})`,
                content: eventData.call.resultPreview,
                pending: true
              }
            ]
          };
        }

        if (eventData.type === "tool_result" && eventData.call) {
          const call = eventData.call;
          return {
            ...item,
            blocks: blocks.map((block) =>
              block.kind === "tool" && block.pending
                ? {
                    ...block,
                    title: `readFile(${call.args.fname})`,
                    content: call.resultPreview,
                    pending: false
                  }
                : block
            )
          };
        }

        if (eventData.type === "answer_delta") {
          const nextBlocks = appendAnswerDelta(finishStatus(blocks), eventData.text || "");
          return {
            ...item,
            content: `${item.content}${eventData.text || ""}`,
            blocks: nextBlocks
          };
        }

        if (eventData.type === "error") {
          return {
            ...item,
            pending: false,
            blocks: [
              ...finishStatus(blocks),
              {
                id: makeId(),
                kind: "error",
                title: "调用失败",
                content: eventData.message || "Agent 调用失败。"
              }
            ]
          };
        }

        if (eventData.type === "done") {
          return {
            ...item,
            pending: false,
            blocks: finishStatus(blocks)
          };
        }

        return item;
      })
    );
  };

  return (
    <section className="chatGrid chatGridWide">
      <div className="heroCopy chatIntro">
        <p className="eyebrow">Tool-Using Agent</p>
        <h1>On-Call Agent</h1>
        <p>Agent 通过唯一工具 readFile(fname) 读取 SOP，并在对话中展示思考、工具调用和处理建议。</p>
        <form className="searchBox chatInput" onSubmit={submit}>
          <input value={message} onChange={(event) => setMessage(event.target.value)} aria-label="输入 On-Call 问题" />
          <button disabled={loading}>{loading ? "处理中" : "发送"}</button>
        </form>
        <div className="quickPrompts">
          {["服务 OOM 了怎么办？", "P0 故障的响应流程是什么？", "怀疑有人入侵了系统", "推荐结果质量下降了"].map(
            (item) => (
              <button key={item} onClick={() => setMessage(item)}>
                {item}
              </button>
            )
          )}
        </div>
      </div>

      <div className="panel chatPanel chatPanelWide">
        <div className="panelHeader">
          <span>对话历史</span>
          <span>{Math.floor(messages.length / 2)} turns</span>
        </div>
        <div className="messageList">
          {messages.map((item) => (
            <article key={item.id} className={`messageTurn ${item.role === "user" ? "messageTurnUser" : "messageTurnAssistant"}`}>
              {item.role === "user" ? (
                <div className="userBubble">{item.content}</div>
              ) : (
                <div className="assistantBubble">
                  {item.blocks?.map((block) => (
                    <div key={block.id} className={`agentBlock agentBlock-${block.kind}`}>
                      <div className="agentBlockHeader">
                        {block.pending && <span className="loadingDot" aria-hidden="true" />}
                        {block.title || (block.kind === "status" ? "Agent" : block.kind === "answer" ? "回答" : "工具调用")}
                      </div>
                      <div className="agentBlockText">
                        <MarkdownView content={block.content} compact={block.kind !== "answer"} />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </article>
          ))}
          {messages.length === 0 && <p className="emptyText">发送问题后，Agent 会读取 SOP 并给出处理建议。</p>}
        </div>
      </div>
    </section>
  );
}

async function readStream(body: ReadableStream<Uint8Array>, onEvent: (event: StreamEvent) => void): Promise<void> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const parts = buffer.split("\n\n");
    buffer = parts.pop() || "";

    for (const part of parts) {
      const line = part
        .split("\n")
        .find((item) => item.startsWith("data: "));
      if (!line) continue;
      onEvent(JSON.parse(line.slice(6)) as StreamEvent);
    }
  }
}

function upsertStatusBlock(blocks: AgentBlock[], content: string): AgentBlock[] {
  const last = blocks[blocks.length - 1];
  if (last?.kind === "status" && last.pending) {
    return [...blocks.slice(0, -1), { ...last, content, pending: true }];
  }
  return [...blocks, { id: makeId(), kind: "status", content, pending: true }];
}

function finishStatus(blocks: AgentBlock[]): AgentBlock[] {
  return blocks.map((block) => (block.kind === "status" ? { ...block, pending: false } : block));
}

function appendAnswerDelta(blocks: AgentBlock[], text: string): AgentBlock[] {
  const last = blocks[blocks.length - 1];
  if (last?.kind === "answer") {
    return [...blocks.slice(0, -1), { ...last, content: `${last.content}${text}` }];
  }
  return [...blocks, { id: makeId(), kind: "answer", title: "回答", content: text }];
}

function makeId(): string {
  return globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`;
}

function MarkdownView({ content, compact = false }: { content: string; compact?: boolean }) {
  const lines = content.split("\n");
  const nodes: ReactNode[] = [];
  let listItems: string[] = [];

  const flushList = () => {
    if (listItems.length === 0) return;
    nodes.push(
      <ul key={`list-${nodes.length}`} className={compact ? "mdList compact" : "mdList"}>
        {listItems.map((item, index) => (
          <li key={`${item}-${index}`}>{renderInlineMarkdown(item)}</li>
        ))}
      </ul>
    );
    listItems = [];
  };

  lines.forEach((line, index) => {
    const trimmed = line.trim();
    if (!trimmed) {
      flushList();
      return;
    }

    if (/^[-*]\s+/.test(trimmed)) {
      listItems.push(trimmed.replace(/^[-*]\s+/, ""));
      return;
    }

    flushList();
    if (trimmed.startsWith("### ")) {
      nodes.push(<h4 key={index}>{renderInlineMarkdown(trimmed.slice(4))}</h4>);
    } else if (trimmed.startsWith("## ")) {
      nodes.push(<h3 key={index}>{renderInlineMarkdown(trimmed.slice(3))}</h3>);
    } else if (trimmed.startsWith("# ")) {
      nodes.push(<h2 key={index}>{renderInlineMarkdown(trimmed.slice(2))}</h2>);
    } else if (/^\d+\.\s+/.test(trimmed)) {
      nodes.push(<p key={index} className="mdNumbered">{renderInlineMarkdown(trimmed)}</p>);
    } else if (/^\|.*\|$/.test(trimmed)) {
      nodes.push(<pre key={index} className="mdTableLine">{trimmed}</pre>);
    } else {
      nodes.push(<p key={index}>{renderInlineMarkdown(trimmed)}</p>);
    }
  });

  flushList();
  return <>{nodes}</>;
}

function renderInlineMarkdown(value: string) {
  const parts = value.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, index) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return <strong key={index}>{part.slice(2, -2)}</strong>;
    }
    return <span key={index}>{part}</span>;
  });
}
