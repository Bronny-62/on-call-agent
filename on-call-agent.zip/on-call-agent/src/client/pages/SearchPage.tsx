import { FormEvent, useEffect, useState } from "react";

interface SearchResult {
  id: string;
  title: string;
  snippet: string;
  score: number;
}

interface SearchResponse {
  query: string;
  results: SearchResult[];
}

export function SearchPage({ phase }: { phase: "v1" | "v2" }) {
  const initialQuery = new URLSearchParams(window.location.search).get("q") || (phase === "v1" ? "OOM" : "服务器挂了");
  const [query, setQuery] = useState(initialQuery);
  const [response, setResponse] = useState<SearchResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const runSearch = async (nextQuery: string, updateUrl: boolean) => {
    setLoading(true);
    setError("");

    try {
      const result = await fetch(`/${phase}/search?q=${encodeURIComponent(nextQuery)}`);
      if (!result.ok) throw new Error(`HTTP ${result.status}`);
      setResponse((await result.json()) as SearchResponse);
      if (updateUrl) {
        const nextUrl = nextQuery ? `/${phase}?q=${encodeURIComponent(nextQuery)}` : `/${phase}`;
        window.history.replaceState(null, "", nextUrl);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "搜索失败");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const q = new URLSearchParams(window.location.search).get("q");
    if (q) {
      void runSearch(q, false);
    }
  }, []);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    await runSearch(query, true);
  };

  const title = phase === "v1" ? "关键词搜索引擎" : "语义搜索";
  const description =
    phase === "v1"
      ? "只检索 HTML 可见正文，过滤脚本和样式内容。"
      : "结合领域意图、结构化标签和关键词召回，支持非精确表达。";

  return (
    <section className="heroGrid">
      <div className="heroCopy">
        <p className="eyebrow">On-Call SOP Retrieval</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <form className="searchBox" onSubmit={submit}>
          <input value={query} onChange={(event) => setQuery(event.target.value)} aria-label="搜索问题" />
          <button disabled={loading}>{loading ? "搜索中" : "搜索"}</button>
        </form>
        <div className="quickPrompts">
          {(phase === "v1" ? ["OOM", "故障", "replication", "CDN", "&"] : ["服务器挂了", "黑客攻击", "机器学习模型出问题"]).map(
            (item) => (
              <button key={item} onClick={() => setQuery(item)}>
                {item}
              </button>
            )
          )}
        </div>
        {error && <p className="errorText">{error}</p>}
      </div>

      <div className="panel resultsPanel">
        <div className="panelHeader">
          <span>{response ? `查询：${response.query || "(空)"}` : "等待查询"}</span>
          <span>{response ? `${response.results.length} 条结果` : phase.toUpperCase()}</span>
        </div>
        <div className="resultList">
          {response?.results.map((result) => (
            <a
              key={result.id}
              className="resultCard"
              href={`/documents/${result.id}.html?returnTo=${encodeURIComponent(`/${phase}?q=${encodeURIComponent(response.query)}`)}`}
              aria-label={`查看 ${result.title}`}
            >
              <div>
                <strong>{result.title}</strong>
                <span>{result.id}</span>
              </div>
              <p>{result.snippet}</p>
              <small>score {result.score.toFixed(3)} · 查看完整 SOP</small>
            </a>
          ))}
          {response && response.results.length === 0 && <p className="emptyText">未找到匹配 SOP。</p>}
          {!response && <p className="emptyText">输入查询后会在这里展示结果。</p>}
        </div>
      </div>
    </section>
  );
}
