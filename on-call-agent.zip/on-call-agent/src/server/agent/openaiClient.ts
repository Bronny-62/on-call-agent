import type { LlmConfig } from "../config.js";

export interface ChatToolCall {
  id: string;
  type: "function";
  function: {
    name: string;
    arguments: string;
  };
}

export interface ChatMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string | null;
  reasoning_content?: string;
  tool_call_id?: string;
  tool_calls?: ChatToolCall[];
}

export interface ChatChoiceMessage {
  role: "assistant";
  content: string | null;
  reasoning_content?: string;
  tool_calls?: ChatToolCall[];
}

export class LlmCallError extends Error {}

const READ_FILE_TOOL = {
  type: "function",
  function: {
    name: "readFile",
    description: "Read one SOP HTML file from the data directory by exact basename. No directory listing or wildcard is available.",
    parameters: {
      type: "object",
      properties: {
        fname: {
          type: "string",
          description: "SOP filename such as sop-002.html"
        }
      },
      required: ["fname"],
      additionalProperties: false
    }
  }
} as const;

export async function createChatCompletion(
  config: LlmConfig,
  messages: ChatMessage[]
): Promise<ChatChoiceMessage> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.timeoutMs);

  try {
    const response = await fetch(`${config.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${config.apiKey}`
      },
      body: JSON.stringify({
        model: config.model,
        messages,
        tools: [READ_FILE_TOOL],
        tool_choice: "auto",
        temperature: config.model.startsWith("kimi-") ? 0.6 : 1,
        ...(config.model.startsWith("kimi-") ? { thinking: { type: "disabled" } } : {})
      }),
      signal: controller.signal
    });

    const payload = (await response.json().catch(() => ({}))) as {
      choices?: Array<{ message?: ChatChoiceMessage }>;
      error?: { message?: string; type?: string };
    };

    if (!response.ok) {
      const message = payload.error?.message || `LLM request failed with HTTP ${response.status}`;
      throw new LlmCallError(message);
    }

    const message = payload.choices?.[0]?.message;
    if (!message) {
      throw new LlmCallError("LLM response does not contain choices[0].message.");
    }

    return message;
  } catch (error) {
    if (error instanceof LlmCallError) {
      throw error;
    }
    if (error instanceof Error && error.name === "AbortError") {
      throw new LlmCallError(`LLM request timed out after ${config.timeoutMs}ms.`);
    }
    throw new LlmCallError(error instanceof Error ? error.message : "Unknown LLM request error.");
  } finally {
    clearTimeout(timeout);
  }
}

export async function* createChatCompletionStream(
  config: LlmConfig,
  messages: ChatMessage[]
): AsyncGenerator<string> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.timeoutMs);

  try {
    const response = await fetch(`${config.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${config.apiKey}`
      },
      body: JSON.stringify({
        model: config.model,
        messages,
        stream: true,
        temperature: config.model.startsWith("kimi-") ? 0.6 : 1,
        ...(config.model.startsWith("kimi-") ? { thinking: { type: "disabled" } } : {})
      }),
      signal: controller.signal
    });

    if (!response.ok) {
      const payload = (await response.json().catch(() => ({}))) as { error?: { message?: string } };
      throw new LlmCallError(payload.error?.message || `LLM stream failed with HTTP ${response.status}`);
    }

    if (!response.body) {
      throw new LlmCallError("LLM stream response does not contain a body.");
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const chunks = buffer.split("\n\n");
      buffer = chunks.pop() || "";

      for (const chunk of chunks) {
        const lines = chunk.split("\n").filter((line) => line.startsWith("data: "));
        for (const line of lines) {
          const data = line.slice(6).trim();
          if (data === "[DONE]") {
            return;
          }
          const parsed = JSON.parse(data) as { choices?: Array<{ delta?: { content?: string } }> };
          const text = parsed.choices?.[0]?.delta?.content;
          if (text) {
            yield text;
          }
        }
      }
    }
  } catch (error) {
    if (error instanceof LlmCallError) {
      throw error;
    }
    if (error instanceof Error && error.name === "AbortError") {
      throw new LlmCallError(`LLM stream timed out after ${config.timeoutMs}ms.`);
    }
    throw new LlmCallError(error instanceof Error ? error.message : "Unknown LLM stream error.");
  } finally {
    clearTimeout(timeout);
  }
}
