import { readFile } from "node:fs/promises";
import path from "node:path";
import * as cheerio from "cheerio";

export class ToolError extends Error {}

export async function readSopFile(dataDir: string, fname: string): Promise<string> {
  if (!isSafeFilename(fname)) {
    throw new ToolError("readFile only accepts a data/ basename like sop-002.html");
  }

  return readFile(path.join(dataDir, fname), "utf-8");
}

export function htmlToMarkdown(html: string): string {
  const $ = cheerio.load(html, { xml: false });
  $("script, style, noscript, template").remove();

  const lines: string[] = [];
  const root = $("body").length ? $("body") : $("html");

  root.find("h1, h2, h3, p, li").each((_, element) => {
    const tagName = element.tagName?.toLowerCase();
    const text = normalize($(element).text());
    if (!text) return;

    if (tagName === "h1") lines.push(`# ${text}`);
    else if (tagName === "h2") lines.push(`## ${text}`);
    else if (tagName === "h3") lines.push(`### ${text}`);
    else if (tagName === "li") lines.push(`- ${text}`);
    else lines.push(text);
  });

  return lines.join("\n\n");
}

export function isSafeFilename(fname: string): boolean {
  return (
    path.basename(fname) === fname &&
    !fname.includes("*") &&
    !fname.includes("?") &&
    /^sop-\d+\.html$/i.test(fname)
  );
}

function normalize(value: string): string {
  return value.replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
}
