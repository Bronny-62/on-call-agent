export interface DocumentSection {
  heading: string;
  content: string;
}

export interface SopDocument {
  id: string;
  filename: string;
  title: string;
  text: string;
  sections: DocumentSection[];
  tags: string[];
  html: string;
}

export interface SearchResult {
  id: string;
  title: string;
  snippet: string;
  score: number;
}

export interface ToolCallTrace {
  name: "readFile";
  args: {
    fname: string;
  };
  resultPreview: string;
}
