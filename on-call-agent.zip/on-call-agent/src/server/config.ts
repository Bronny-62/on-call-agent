import "dotenv/config";

export interface LlmConfig {
  model: string;
  apiKey: string;
  baseUrl: string;
  timeoutMs: number;
  maxTurns: number;
}

export class ConfigError extends Error {}

export function loadLlmConfig(env: NodeJS.ProcessEnv = process.env): LlmConfig {
  const apiKey = env.LLM_API_KEY?.trim() || env.MOONSHOT_API_KEY?.trim() || env.OPENAI_API_KEY?.trim();
  if (!apiKey) {
    throw new ConfigError("LLM_API_KEY is required. Put it in .env before using /v3/chat.");
  }

  return {
    model: env.LLM_MODEL?.trim() || "kimi-k2.6",
    apiKey,
    baseUrl: trimTrailingSlash(env.LLM_BASE_URL?.trim() || "https://api.moonshot.cn/v1"),
    timeoutMs: parsePositiveInt(env.LLM_TIMEOUT_MS, 30_000),
    maxTurns: parsePositiveInt(env.LLM_MAX_TURNS, 6)
  };
}

function trimTrailingSlash(value: string): string {
  return value.replace(/\/+$/, "");
}

function parsePositiveInt(value: string | undefined, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : fallback;
}
