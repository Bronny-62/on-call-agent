import fastifyStatic from "@fastify/static";
import Fastify, { type FastifyInstance, type FastifyReply } from "fastify";
import { existsSync } from "node:fs";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { DocumentStore } from "./documents/store.js";
import { registerDocumentRoutes } from "./routes/documents.js";
import { registerV1Routes } from "./routes/v1.js";
import { registerV2Routes } from "./routes/v2.js";
import { registerV3Routes } from "./routes/v3.js";

interface AppOptions {
  rootDir?: string;
  logger?: boolean;
}

export async function buildApp(options: AppOptions = {}): Promise<FastifyInstance> {
  const rootDir = options.rootDir ?? process.cwd();
  const app = Fastify({ logger: options.logger ?? false });
  const store = new DocumentStore(path.join(rootDir, "data"));
  await store.loadFromDisk();

  await registerV1Routes(app, store);
  await registerV2Routes(app, store);
  await registerV3Routes(app, store);
  await registerDocumentRoutes(app, store);
  registerPageRoutes(app, rootDir);

  return app;
}

function registerPageRoutes(app: FastifyInstance, rootDir: string): void {
  const clientDir = path.join(rootDir, "dist", "client");
  const indexPath = path.join(clientDir, "index.html");

  app.get("/v1", async (_request, reply) => sendClientEntry(reply, indexPath, "/v1"));
  app.get("/v2", async (_request, reply) => sendClientEntry(reply, indexPath, "/v2"));
  app.get("/v3", async (_request, reply) => sendClientEntry(reply, indexPath, "/v3"));

  if (existsSync(clientDir)) {
    app.register(fastifyStatic, {
      root: clientDir,
      prefix: "/",
      decorateReply: false
    });
  }
}

async function sendClientEntry(reply: FastifyReply, indexPath: string, pagePath: string): Promise<void> {
  try {
    const html = await readFile(indexPath, "utf-8");
    reply.type("text/html; charset=utf-8").send(html);
  } catch {
    if (process.env.NODE_ENV === "production") {
      reply.status(503).send({ error: "Client assets are missing. Run npm run build before npm start." });
      return;
    }
    reply.redirect(`http://localhost:5173${pagePath}`);
  }
}
