import type { SearchResult, SopDocument } from "../types.js";
import { countOccurrences, keywordSearch, makeSnippet, roundScore } from "./keyword.js";

interface IntentRule {
  name: string;
  triggers: string[];
  tags: string[];
  terms: string[];
  documentBoosts?: Record<string, number>;
}

const INTENTS: IntentRule[] = [
  {
    name: "service-down",
    triggers: ["服务器挂了", "服务挂了", "服务不可用", "网站挂了", "宕机", "超时", "500", "服务异常"],
    tags: ["backend", "sre", "network"],
    terms: ["服务", "超时", "不可用", "告警", "基础设施", "Kubernetes", "Ingress", "降级", "熔断"],
    documentBoosts: { "sop-001": 1.2, "sop-004": 0.9, "sop-010": 0.25 }
  },
  {
    name: "security-attack",
    triggers: ["黑客攻击", "入侵", "被攻击", "安全事件", "攻击", "漏洞", "数据泄露", "恶意"],
    tags: ["security", "network"],
    terms: ["安全", "攻击", "入侵", "DDoS", "SQL注入", "WAF", "漏洞", "泄露", "恶意软件"],
    documentBoosts: { "sop-005": 1.5, "sop-010": 0.35 }
  },
  {
    name: "ml-model",
    triggers: ["机器学习", "模型", "推荐结果", "推荐质量", "算法", "推理", "GPU", "AI"],
    tags: ["ai"],
    terms: ["AI", "算法", "模型", "推荐", "推理", "GPU", "特征", "召回", "排序"],
    documentBoosts: { "sop-008": 1.5 }
  },
  {
    name: "database",
    triggers: ["数据库", "主从", "延迟", "慢查询", "连接池", "复制", "Redis"],
    tags: ["database"],
    terms: ["数据库", "主从", "复制", "延迟", "慢查询", "连接数", "恢复", "Binlog"],
    documentBoosts: { "sop-002": 1.4 }
  },
  {
    name: "frontend-cdn",
    triggers: ["白屏", "页面", "前端", "浏览器", "CDN资源", "JS错误"],
    tags: ["frontend", "network"],
    terms: ["白屏", "页面", "JavaScript", "CDN", "资源", "浏览器", "Lighthouse"],
    documentBoosts: { "sop-003": 1.0, "sop-010": 0.35 }
  },
  {
    name: "p0-incident",
    triggers: ["P0", "故障响应", "响应流程", "升级流程", "重大故障"],
    tags: ["backend", "sre", "security", "network"],
    terms: ["P0", "升级", "响应", "故障", "负责人", "VP", "CISO", "五分钟", "三分钟"],
    documentBoosts: { "sop-001": 0.45, "sop-004": 0.45, "sop-005": 0.45, "sop-010": 0.45 }
  }
];

export function hybridSearch(documents: SopDocument[], query: string): SearchResult[] {
  const lexical = keywordSearch(documents, query);
  const lexicalScores = new Map(lexical.map((result, index) => [result.id, Math.max(0.1, 1 - index * 0.08)]));
  const activeRules = getActiveIntentRules(query);
  const queryTokens = tokenize(query);

  const scored = documents
    .map((document) => {
      const semanticScore = scoreDocument(document, query, queryTokens, activeRules);
      const lexicalScore = lexicalScores.get(document.id) ?? 0;
      const rawScore = semanticScore + lexicalScore * 0.35;
      if (rawScore <= 0) return null;

      const bestSection = selectBestSection(document, queryTokens, activeRules);
      return {
        id: document.id,
        title: document.title,
        snippet: makeSnippet(document, query, bestSection),
        rawScore
      };
    })
    .filter((result): result is SearchResult & { rawScore: number } => Boolean(result))
    .sort((a, b) => b.rawScore - a.rawScore || a.id.localeCompare(b.id));

  const maxScore = scored[0]?.rawScore || 1;
  return scored.slice(0, 8).map(({ rawScore, ...result }) => ({
    ...result,
    score: roundScore(Math.min(1, rawScore / maxScore))
  }));
}

export function getActiveIntentRules(query: string): IntentRule[] {
  const folded = query.toLocaleLowerCase("zh-CN");
  return INTENTS.filter((rule) =>
    rule.triggers.some((trigger) => folded.includes(trigger.toLocaleLowerCase("zh-CN")))
  );
}

function scoreDocument(
  document: SopDocument,
  query: string,
  queryTokens: string[],
  activeRules: IntentRule[]
): number {
  let score = 0;
  const text = `${document.title} ${document.text}`;

  score += countOccurrences(text, query) * 0.2;
  for (const token of queryTokens) {
    score += Math.min(countOccurrences(text, token), 3) * 0.06;
  }

  for (const rule of activeRules) {
    score += rule.documentBoosts?.[document.id] ?? 0;
    score += rule.tags.filter((tag) => document.tags.includes(tag)).length * 0.25;
    score += rule.terms.filter((term) => text.toLocaleLowerCase("zh-CN").includes(term.toLocaleLowerCase("zh-CN"))).length * 0.08;
  }

  return score;
}

function selectBestSection(document: SopDocument, queryTokens: string[], activeRules: IntentRule[]): string | undefined {
  const terms = [...queryTokens, ...activeRules.flatMap((rule) => rule.terms)];
  return document.sections
    .map((section) => {
      const content = `${section.heading} ${section.content}`;
      const score = terms.reduce((total, term) => total + countOccurrences(content, term), 0);
      return { content, score };
    })
    .sort((a, b) => b.score - a.score)[0]?.content;
}

function tokenize(query: string): string[] {
  const words = query
    .split(/[\s,，。；;:：!?！？]+/)
    .map((word) => word.trim())
    .filter(Boolean);

  const grams = new Set(words);
  for (const word of words) {
    if (/^[\u4e00-\u9fff]+$/.test(word) && word.length > 2) {
      for (let size = 2; size <= Math.min(4, word.length); size += 1) {
        for (let index = 0; index <= word.length - size; index += 1) {
          grams.add(word.slice(index, index + size));
        }
      }
    }
  }

  return [...grams];
}
