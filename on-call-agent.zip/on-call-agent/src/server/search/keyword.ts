import type { SearchResult, SopDocument } from "../types.js";

export function keywordSearch(documents: SopDocument[], query: string): SearchResult[] {
  const normalizedQuery = normalizeQuery(query);
  if (!normalizedQuery) {
    return [];
  }

  return documents
    .map((document) => {
      const titleHits = countOccurrences(document.title, normalizedQuery);
      const sectionHits = document.sections.reduce(
        (total, section) => total + countOccurrences(section.heading, normalizedQuery),
        0
      );
      const textHits = countOccurrences(document.text, normalizedQuery);
      const firstIndex = indexOfFolded(document.text, normalizedQuery);

      if (titleHits + sectionHits + textHits === 0) {
        return null;
      }

      const positionBoost = firstIndex >= 0 ? Math.max(0, 1 - firstIndex / Math.max(document.text.length, 1)) : 0;
      const score = titleHits * 5 + sectionHits * 3 + textHits + positionBoost;

      return {
        id: document.id,
        title: document.title,
        snippet: makeSnippet(document, normalizedQuery),
        score: roundScore(score)
      };
    })
    .filter((result): result is SearchResult => Boolean(result))
    .sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
}

export function makeSnippet(document: SopDocument, query: string, preferredSection?: string): string {
  const source = preferredSection || bestSectionContent(document, query) || document.text;
  const index = indexOfFolded(source, query);

  if (index < 0) {
    return truncate(source, 150);
  }

  const start = Math.max(0, index - 55);
  const end = Math.min(source.length, index + query.length + 95);
  const prefix = start > 0 ? "..." : "";
  const suffix = end < source.length ? "..." : "";
  return `${prefix}${source.slice(start, end)}${suffix}`;
}

export function normalizeQuery(query: string): string {
  return query.replace(/\+/g, " ").trim();
}

export function countOccurrences(text: string, query: string): number {
  const haystack = fold(text);
  const needle = fold(query);
  if (!needle) return 0;

  let count = 0;
  let index = haystack.indexOf(needle);
  while (index >= 0) {
    count += 1;
    index = haystack.indexOf(needle, index + Math.max(needle.length, 1));
  }
  return count;
}

export function indexOfFolded(text: string, query: string): number {
  return fold(text).indexOf(fold(query));
}

export function roundScore(score: number): number {
  return Number(score.toFixed(3));
}

function bestSectionContent(document: SopDocument, query: string): string | undefined {
  return document.sections
    .map((section) => ({
      content: `${section.heading} ${section.content}`,
      hits: countOccurrences(`${section.heading} ${section.content}`, query)
    }))
    .sort((a, b) => b.hits - a.hits)[0]?.content;
}

function truncate(value: string, maxLength: number): string {
  if (value.length <= maxLength) return value;
  return `${value.slice(0, maxLength)}...`;
}

function fold(value: string): string {
  return value.toLocaleLowerCase("zh-CN");
}
