import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import { parseHtmlDocument } from "./parser.js";
import type { SopDocument } from "../types.js";

export class DocumentStore {
  private readonly documents = new Map<string, SopDocument>();

  constructor(private readonly dataDir: string) {}

  async loadFromDisk(): Promise<void> {
    const filenames = await readdir(this.dataDir);
    const htmlFiles = filenames.filter((name) => /^sop-\d+\.html$/i.test(name)).sort();

    for (const filename of htmlFiles) {
      const html = await readFile(path.join(this.dataDir, filename), "utf-8");
      const id = filename.replace(/\.html$/i, "");
      this.addDocument(id, html, filename);
    }
  }

  addDocument(id: string, html: string, filename = `${id}.html`): SopDocument {
    const document = parseHtmlDocument(id, html, filename);
    this.documents.set(document.id, document);
    return document;
  }

  all(): SopDocument[] {
    return [...this.documents.values()].sort((a, b) => a.id.localeCompare(b.id));
  }

  getById(id: string): SopDocument | undefined {
    return this.documents.get(id);
  }

  getByFilename(filename: string): SopDocument | undefined {
    return this.all().find((document) => document.filename === filename);
  }

  getDataDir(): string {
    return this.dataDir;
  }
}
