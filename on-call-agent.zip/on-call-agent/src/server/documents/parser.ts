import * as cheerio from "cheerio";
import type { AnyNode } from "domhandler";
import type { DocumentSection, SopDocument } from "../types.js";

const TAG_RULES: Array<[string, string[]]> = [
  ["backend", ["后端", "服务", "OOM", "超时", "降级", "熔断"]],
  ["database", ["数据库", "DBA", "MySQL", "PostgreSQL", "Redis", "主从", "复制", "慢查询"]],
  ["frontend", ["前端", "Web", "白屏", "JavaScript", "CDN资源", "浏览器"]],
  ["sre", ["SRE", "Kubernetes", "K8s", "Etcd", "Ingress", "基础设施"]],
  ["security", ["安全", "入侵", "攻击", "DDoS", "SQL注入", "WAF", "漏洞", "泄露"]],
  ["data", ["数据平台", "ETL", "Spark", "数据管道", "Hive", "Flink"]],
  ["mobile", ["移动端", "App", "崩溃", "热修复", "推送"]],
  ["ai", ["AI", "算法", "模型", "推荐", "GPU", "推理", "机器学习"]],
  ["qa", ["QA", "测试", "自动化", "发版", "环境"]],
  ["network", ["网络", "CDN", "DNS", "DDoS", "负载均衡", "BGP"]]
];

export function normalizeText(value: string): string {
  return value
    .replace(/\u00a0/g, " ")
    .replace(/[ \t\r\n]+/g, " ")
    .replace(/\s*([，。；：、,.!?！？;:])\s*/g, "$1")
    .trim();
}

export function parseHtmlDocument(id: string, html: string, filename = `${id}.html`): SopDocument {
  const $ = cheerio.load(html, { xml: false });
  $("script, style, noscript, template").remove();

  const title = normalizeText($("h1").first().text() || $("title").first().text() || id);
  const body = $("body").length ? $("body") : $("html");
  const text = normalizeText(body.text());
  const sections = extractSections($, body);
  const tags = deriveTags(`${title} ${text}`);

  return {
    id,
    filename,
    title,
    text,
    sections,
    tags,
    html
  };
}

function extractSections($: cheerio.CheerioAPI, body: cheerio.Cheerio<AnyNode>): DocumentSection[] {
  const sections: DocumentSection[] = [];
  let current: DocumentSection | null = null;

  body.find("h2, h3, p, li").each((_, element) => {
    const tagName = "tagName" in element && typeof element.tagName === "string" ? element.tagName.toLowerCase() : "";
    const value = normalizeText($(element).text());
    if (!value) return;

    if (tagName === "h2" || tagName === "h3") {
      current = { heading: value, content: "" };
      sections.push(current);
      return;
    }

    if (!current) {
      current = { heading: "正文", content: "" };
      sections.push(current);
    }

    current.content = normalizeText(`${current.content} ${value}`);
  });

  return sections.filter((section) => section.heading || section.content);
}

function deriveTags(text: string): string[] {
  const tags = new Set<string>();
  for (const [tag, words] of TAG_RULES) {
    if (words.some((word) => text.toLowerCase().includes(word.toLowerCase()))) {
      tags.add(tag);
    }
  }
  return [...tags];
}
