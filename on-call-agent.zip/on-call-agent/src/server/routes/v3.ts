import type { FastifyInstance } from "fastify";
import type { DocumentStore } from "../documents/store.js";
import { runOnCallAgent, runOnCallAgentStream, type AgentStreamEvent } from "../agent/agent.js";
import { ConfigError, loadLlmConfig } from "../config.js";
import { LlmCallError } from "../agent/openaiClient.js";

interface ChatBody {
  message?: string;
}

export async function registerV3Routes(app: FastifyInstance, store: DocumentStore): Promise<void> {
  app.post("/v3/chat", async (request, reply) => {
    const body = request.body as ChatBody | undefined;
    const message = body?.message?.trim();
    if (!message) {
      return reply.status(400).send({ error: "message is required" });
    }

    try {
      return await runOnCallAgent(store, message, loadLlmConfig());
    } catch (error) {
      if (error instanceof ConfigError) {
        return reply.status(500).send({ error: error.message });
      }
      if (error instanceof LlmCallError) {
        return reply.status(502).send({ error: error.message });
      }
      request.log.error({ err: error }, "v3 chat failed");
      return reply.status(500).send({ error: "Agent failed to answer the question." });
    }
  });

  app.post("/v3/chat/stream", async (request, reply) => {
    const body = request.body as ChatBody | undefined;
    const message = body?.message?.trim();
    if (!message) {
      return reply.status(400).send({ error: "message is required" });
    }

    reply.raw.writeHead(200, {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no"
    });

    const send = (event: AgentStreamEvent) => {
      reply.raw.write(`data: ${JSON.stringify(event)}\n\n`);
    };

    try {
      for await (const event of runOnCallAgentStream(store, message, loadLlmConfig())) {
        send(event);
      }
    } catch (error) {
      const message =
        error instanceof ConfigError || error instanceof LlmCallError || error instanceof Error
          ? error.message
          : "Agent failed to answer the question.";
      send({ type: "error", message });
    } finally {
      reply.raw.end();
    }
  });
}
