import type { FastifyInstance } from "fastify";
import type { DocumentStore } from "../documents/store.js";
import { hybridSearch } from "../search/hybrid.js";
import { extractQuery } from "./query.js";

export async function registerV2Routes(app: FastifyInstance, store: DocumentStore): Promise<void> {
  app.get("/v2/search", async (request) => {
    const query = extractQuery(request);
    return {
      query,
      results: hybridSearch(store.all(), query)
    };
  });
}
