import type { FastifyRequest } from "fastify";

export function extractQuery(request: FastifyRequest): string {
  const url = request.url.split("#")[0] ?? "";
  const queryStart = url.indexOf("?");
  if (queryStart < 0) return "";

  const rawQuery = url.slice(queryStart + 1);
  const qIndex = rawQuery.indexOf("q=");
  if (qIndex < 0) return "";

  let rawValue = rawQuery.slice(qIndex + 2);
  if (rawValue === "&") {
    return "&";
  }

  const nextParam = rawValue.indexOf("&");
  if (nextParam >= 0) {
    rawValue = rawValue.slice(0, nextParam);
  }

  try {
    return decodeURIComponent(rawValue.replace(/\+/g, " "));
  } catch {
    return rawValue;
  }
}
