import type { FastifyInstance } from "fastify";
import * as cheerio from "cheerio";
import type { DocumentStore } from "../documents/store.js";

interface DocumentParams {
  fname: string;
}

interface DocumentQuery {
  returnTo?: string;
}

export async function registerDocumentRoutes(app: FastifyInstance, store: DocumentStore): Promise<void> {
  app.get<{ Params: DocumentParams; Querystring: DocumentQuery }>("/documents/:fname", async (request, reply) => {
    const document = store.getByFilename(request.params.fname);
    if (!document) {
      return reply.status(404).send({ error: "document not found" });
    }

    return reply
      .type("text/html; charset=utf-8")
      .send(renderDocumentPage(document.title, cleanDocumentBody(document.html), safeReturnTo(request.query.returnTo)));
  });
}

function safeReturnTo(value: string | undefined): string {
  if (!value || !/^\/v[12](\?|$)/.test(value)) {
    return "/v1";
  }
  return value;
}

function cleanDocumentBody(html: string): string {
  const $ = cheerio.load(html, { xml: false });
  $("script, style, noscript, template").remove();
  return $("body").html() || $("html").html() || "";
}

function renderDocumentPage(title: string, bodyHtml: string, returnTo: string): string {
  return `<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${escapeHtml(title)}</title>
    <style>
      :root { font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; color: #101117; background: #f8fbff; }
      * { box-sizing: border-box; }
      body { margin: 0; min-height: 100vh; line-height: 1.75; }
      canvas { position: fixed; inset: 0; z-index: -2; }
      .shell { width: min(920px, calc(100vw - 40px)); margin: 0 auto; padding: 22px 0 64px; }
      .topbar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 34px; }
      .brand { display: inline-flex; align-items: center; gap: 10px; font-weight: 700; text-decoration: none; color: inherit; }
      .brandMark { display: inline-grid; width: 24px; height: 24px; place-items: center; border-radius: 9px; color: #1f6fff; background: linear-gradient(135deg, rgba(31,111,255,.16), rgba(117,78,255,.12)); }
      .backLink { color: #4f5a70; text-decoration: none; padding: 9px 13px; border-radius: 999px; background: rgba(255,255,255,.7); border: 1px solid rgba(88,112,150,.14); }
      .documentCard { padding: clamp(24px, 5vw, 48px); border: 1px solid rgba(74,100,148,.16); border-radius: 34px; background: rgba(255,255,255,.78); box-shadow: 0 28px 80px rgba(49,73,112,.16); backdrop-filter: blur(20px); }
      h1 { margin-top: 0; font-size: clamp(32px, 5vw, 54px); line-height: 1.05; letter-spacing: -0.05em; }
      h2 { margin-top: 34px; font-size: 24px; }
      h3 { margin-top: 26px; font-size: 18px; }
      p, li { color: #333b4d; }
      table { width: 100%; border-collapse: collapse; }
      td, th { border: 1px solid rgba(74,100,148,.18); padding: 8px; }
      code { background: rgba(31,111,255,.08); padding: 2px 5px; border-radius: 6px; }
    </style>
  </head>
  <body>
    <canvas id="particles" aria-hidden="true"></canvas>
    <main class="shell">
      <nav class="topbar">
        <a class="brand" href="/v1"><span class="brandMark">A</span>On-Call Agent</a>
        <a class="backLink" href="${escapeHtml(returnTo)}">返回搜索</a>
      </nav>
      <article class="documentCard">${bodyHtml}</article>
    </main>
    <script>
      const canvas = document.getElementById('particles');
      const ctx = canvas.getContext('2d');
      const particles = [];
      const pointer = { x: -9999, y: -9999 };
      function resize() {
        const ratio = window.devicePixelRatio || 1;
        canvas.width = window.innerWidth * ratio;
        canvas.height = window.innerHeight * ratio;
        canvas.style.width = window.innerWidth + 'px';
        canvas.style.height = window.innerHeight + 'px';
        ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
        particles.length = 0;
        const count = Math.min(180, Math.floor(window.innerWidth * window.innerHeight / 9000));
        for (let i = 0; i < count; i++) {
          particles.push({ x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight, vx: (Math.random() - .5) * .35, vy: (Math.random() - .5) * .35, size: Math.random() * 1.8 + .6, hue: 210 + Math.random() * 110 });
        }
      }
      function draw() {
        ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
        ctx.fillStyle = 'rgba(255,255,255,.68)';
        ctx.fillRect(0, 0, window.innerWidth, window.innerHeight);
        for (const p of particles) {
          const dx = p.x - pointer.x;
          const dy = p.y - pointer.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          if (distance < 130) {
            const force = (130 - distance) / 130;
            p.vx += dx / Math.max(distance, 1) * force * .035;
            p.vy += dy / Math.max(distance, 1) * force * .035;
          }
          p.x += p.vx; p.y += p.vy; p.vx *= .992; p.vy *= .992;
          if (p.x < -20) p.x = window.innerWidth + 20;
          if (p.x > window.innerWidth + 20) p.x = -20;
          if (p.y < -20) p.y = window.innerHeight + 20;
          if (p.y > window.innerHeight + 20) p.y = -20;
          ctx.beginPath();
          ctx.fillStyle = 'hsla(' + p.hue + ',76%,48%,.55)';
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
        requestAnimationFrame(draw);
      }
      window.addEventListener('resize', resize);
      window.addEventListener('pointermove', (event) => { pointer.x = event.clientX; pointer.y = event.clientY; });
      resize(); draw();
    </script>
  </body>
</html>`;
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (char) => {
    const entities: Record<string, string> = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    };
    return entities[char];
  });
}
