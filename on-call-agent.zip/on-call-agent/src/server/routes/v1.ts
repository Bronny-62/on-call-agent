import type { FastifyInstance } from "fastify";
import type { DocumentStore } from "../documents/store.js";
import { keywordSearch } from "../search/keyword.js";
import { extractQuery } from "./query.js";

interface DocumentBody {
  id?: string;
  html?: string;
}

export async function registerV1Routes(app: FastifyInstance, store: DocumentStore): Promise<void> {
  app.post("/v1/documents", async (request, reply) => {
    const body = request.body as DocumentBody | undefined;
    if (!body?.id || !body.html) {
      return reply.status(400).send({ error: "id and html are required" });
    }

    const document = store.addDocument(body.id, body.html);
    return reply.status(201).send({ id: document.id, title: document.title });
  });

  app.get("/v1/search", async (request) => {
    const query = extractQuery(request);
    return {
      query,
      results: keywordSearch(store.all(), query)
    };
  });
}
