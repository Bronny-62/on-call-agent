import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/v1/search": "http://localhost:3000",
      "/v1/documents": "http://localhost:3000",
      "/v2/search": "http://localhost:3000",
      "/v3/chat": "http://localhost:3000",
      "/documents": "http://localhost:3000"
    }
  },
  build: {
    outDir: "dist/client",
    emptyOutDir: true
  }
});
