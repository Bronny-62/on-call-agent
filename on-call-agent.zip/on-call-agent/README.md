# On-Call Agent

本项目是一个本地运行的 On-Call 助手 Web 应用，实现了题目要求的三阶段能力：

- `/v1`：关键词 SOP 搜索。
- `/v2`：可解释混合语义搜索。
- `/v3`：真实 LLM 驱动的 On-Call Agent，对话过程中展示 `readFile(fname)` 工具调用。

原始考试题目已保存在 [question-1.md](question-1.md)。

## 快速开始

### 环境准备

本项目是 Node.js/TypeScript 应用，不需要创建 Python 式虚拟环境。依赖会安装到当前项目的 `node_modules/`，并通过 `package-lock.json` 锁定版本。

请先确保本机已安装 Node.js 20+ 版本。

安装依赖：

```bash
npm install
```

配置 LLM：

```bash
cp .env.example .env
```

编辑 `.env`，写入API-KEY

Kimi 开放平台兼容 OpenAI Chat Completions 协议，服务地址为 `https://api.moonshot.cn/v1`，请求头使用 `Authorization: Bearer $MOONSHOT_API_KEY`。参考：[Kimi API 概述](https://platform.kimi.com/docs/api/overview)。

启动开发环境：

```bash
npm run dev
```

访问：

- `http://localhost:5173/v1`
- `http://localhost:5173/v2`
- `http://localhost:5173/v3`

生产构建与运行：

```bash
npm run build
npm start
```

启动后，请访问：

```text
http://localhost:5173/v1
http://localhost:5173/v2
http://localhost:5173/v3
```

## API

### Phase 1

```text
POST /v1/documents
{ "id": "sop-001", "html": "<html>...</html>" }

GET /v1/search?q={query}
```

### Phase 2

```text
GET /v2/search?q={query}
```

### Phase 3

```text
POST /v3/chat
{ "message": "数据库主从延迟超过30秒怎么处理？" }
```

返回结果包含：

- `answer`：LLM 基于 SOP 原文生成的回答。
- `messages`：简化后的对话过程。
- `toolCalls`：Agent 调用 `readFile(fname)` 的顺序、参数和结果摘要。

## 系统架构

```mermaid
flowchart TD
    browser["Browser UI"] --> fastify["Fastify Server"]
    fastify --> v1["/v1 Keyword Search"]
    fastify --> v2["/v2 Hybrid Semantic Search"]
    fastify --> v3["/v3 LLM Agent"]
    v1 --> store["Document Store"]
    v2 --> store
    store --> parser["HTML Parser"]
    v3 --> llm["OpenAI-Compatible LLM"]
    llm --> tool["readFile(fname)"]
    tool --> data["data/*.html"]
```

## 关键实现

- HTML 解析会移除 `script/style/noscript/template`，只索引可见文本，并处理 HTML entity。
- `/v2` 使用关键词、中文 n-gram、领域意图和 SOP 标签融合排序，不依赖外部向量库。
- `/v3` 通过 OpenAI 兼容协议调用 LLM，默认模型为 `kimi-k2.6`，`model`、`api key`、`base_url` 全部从 `.env` 读取。
- Agent 只注册一个工具 `readFile(fname)`，并校验文件名必须是 `sop-xxx.html` 形式的 basename，拒绝目录、通配符和路径穿越。
- 服务端不会记录 API Key，也不会把 Authorization 请求头返回给前端。

## 验收

运行测试：

```bash
npm test
```

